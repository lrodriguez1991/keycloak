# biblioteca-web

Frontend Angular 20 para el proyecto de Security with Keycloak. Consume la API `biblioteca-api` de Spring Boot y está preparado para autenticación OIDC con Keycloak 26.

## 1. Requisitos

- Node.js 24.x
- npm 11.x
- Angular CLI 20.x
- Spring Boot API en `http://localhost:8081`
- Keycloak 26.x en `http://localhost:8080`

## 2. Instalar y levantar

```bash
npm install
npm start
```

Abrir `http://localhost:4200`.

El proxy de desarrollo redirige `/api/*` hacia `http://localhost:8081`.

## 3. Keycloak activo

La aplicacion esta configurada para conectarse a Keycloak desde `src/environments/environment.ts` y `src/environments/environment.development.ts`:

```ts
keycloak: {
  enabled: true,
  url: 'http://localhost:8080',
  realm: 'biblioteca-interna',
  clientId: 'biblioteca-web'
}
```

Con `enabled: true`, el boton `INGRESAR` ejecuta el login real contra Keycloak. Si Keycloak no esta levantado, el frontend no podra completar la inicializacion SSO.

El cliente `biblioteca-web` debe existir en el realm `biblioteca-interna`.

## 4. Cliente Keycloak

- Realm: `biblioteca-interna`
- Client ID: `biblioteca-web`
- Client type: OpenID Connect
- Client authentication: OFF
- Standard flow: ON
- PKCE: S256
- Redirect URI: `http://localhost:4200/*`
- Web origin: `http://localhost:4200`
- Audience del token: `biblioteca-api`

El navegador no debe contener el secret del cliente confidencial `biblioteca-api`.

## 5. API consumida

Públicas:

- `GET /api/public/libros`
- `GET /api/public/libros/{codigo}`

Privadas:

- `GET /api/libros`
- `POST /api/libros`
- `PATCH /api/libros/{id}/estado?estado=DISPONIBLE|PRESTADO`

Seguridad granular:

- `GET /api/recursos-digitales` → resource `libro-digital`, scope `libro:read`
- `GET /api/recursos-digitales/{id}/download` → resource `libro-digital`, scope `libro:download`

## 6. Roles usados en la UI

- `LIBRO_CONSULTAR`
- `LIBRO_CREAR`
- `LIBRO_CAMBIAR_ESTADO`
- `LIBRO_DIGITAL_DESCARGAR`

La UI oculta acciones que no corresponden al rol y muestra el resultado 401/403 de la API. La autorización real debe permanecer en backend + Keycloak.

## 7. Estructura

```text
src/app/
├── core/
│   ├── auth/
│   ├── guards/
│   ├── interceptors/
│   ├── models/
│   └── services/
├── layout/
├── pages/
│   ├── dashboard/
│   ├── forbidden/
│   ├── home/
│   ├── libros/
│   ├── login/
│   └── recursos-digitales/
├── app.component.ts
└── app.routes.ts
```

## 8. Relación con la rúbrica

La aplicación cubre el componente "App Web - Angular" de la rúbrica: modelo de aplicación web, accesos públicos/privados/especiales y matriz funcional basada en usuarios/roles/recursos. La integración con Keycloak se mantiene lista para activarse.

## Estructura de componentes

Los templates HTML de los componentes están separados de la lógica TypeScript para facilitar mantenimiento y aprendizaje:

- `*.component.ts` → lógica del componente.
- `*.component.html` → interfaz/template.
- `*.component.css` → estilos propios del componente.
- `src/styles.css` → estilos globales mínimos.

Los componentes usan `templateUrl` y `styleUrl` en lugar de `template`/`styles` inline.

El detalle de cómo se mapeó el prototipo está en `docs/prototipo-mapeo.md`.
