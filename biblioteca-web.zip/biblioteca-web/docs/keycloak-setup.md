# Configuración de Keycloak para biblioteca-web

## Realm

`biblioteca-interna`

## Cliente

Crear `biblioteca-web` como OpenID Connect público:

- Client authentication: OFF
- Standard flow: ON
- Direct access grants: OFF
- Valid redirect URIs: `http://localhost:4200/*`
- Web origins: `http://localhost:4200`

Usar Authorization Code + PKCE S256.

## Audience

El access token que consume Spring Boot debe contener:

```json
"aud": ["biblioteca-api", "account"]
```

Para ello, configurar en `biblioteca-web` un mapper de tipo Audience que incluya `biblioteca-api` en el access token.

## Roles

Los roles que utiliza el frontend son:

```text
LIBRO_CONSULTAR
LIBRO_CREAR
LIBRO_CAMBIAR_ESTADO
LIBRO_DIGITAL_DESCARGAR
```

## Seguridad granular

La autorización granular pertenece al cliente `biblioteca-api`:

```text
Resource: libro-digital
Scopes: libro:read, libro:download
```

El frontend no debe contener el secret de `biblioteca-api`.
