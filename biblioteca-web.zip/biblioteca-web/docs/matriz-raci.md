# Matriz funcional / RACI

| Operación | Supervisor | Bibliotecario | Admin | Público |
|---|---|---|---|---|
| Consultar catálogo público | R | R | R | R |
| Consultar libros internos | R | R | R | I |
| Crear libro | I | I | A/R | I |
| Cambiar estado | I | A/R | C | I |
| Consultar recurso digital | A/R | R | R | I |
| Descargar recurso digital | I | A/R* | A/R* | I |
| Administrar Keycloak | I | I | A/R | I |

`*` La operación depende además del scope/policy/permission configurado en Authorization Services.
