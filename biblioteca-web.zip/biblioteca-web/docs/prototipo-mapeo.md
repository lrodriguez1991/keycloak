# Mapeo del prototipo de Biblioteca KeyCloak

La interfaz se ajustó al prototipo de 3 pantallas entregado para el proyecto.

## Pantalla 1 — Catálogo público
- Encabezado azul con `Biblioteca KeyCloak` y botón `Ingresar`.
- Título y descripción de la biblioteca.
- Botón `Ver Catalogo`.
- Tabla pública con TÍTULO, AUTOR y ESTADO.
- Clic en una fila para consultar el detalle por código mediante `GET /api/public/libros/{codigo}`.
- Panel de detalle con Título, Código, Autor y Estado.
- `Separa tu libro` lleva al flujo de login.

## Pantalla 2 — Login
- Tarjeta centrada `BIBLIOTECA KEYCLOAK`.
- Campos visuales de usuario y contraseña como en el prototipo.
- El botón `INGRESAR` ejecuta el flujo real de Keycloak cuando `environment.keycloak.enabled = true`.
- Mientras Keycloak está desactivado, el botón entra en modo demo para poder revisar el frontend.

## Pantalla 3 — Gestión de libros
- Encabezado `GESTIÓN DE LIBROS`.
- Opción `Nuevo` para registrar un libro.
- Tabla con ACCIONES, CÓDIGO, TÍTULO, AUTOR y ESTADO.
- Acción para actualizar estado mediante popup.
- Acción para visualizar el recurso digital mediante popup.
- Acción para descargar el recurso digital.
- Las acciones se muestran según los roles configurados.

## Separación por componente
Cada componente tiene sus archivos separados:

```text
componente/
├── componente.component.ts
├── componente.component.html
└── componente.component.css
```

No se utiliza `template: \`...\`` ni estilos inline en los componentes.
