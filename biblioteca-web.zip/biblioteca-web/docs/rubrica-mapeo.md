# Mapeo con la rúbrica

| Rubro | Evidencia en el frontend |
|---|---|
| Keycloak | Cliente `biblioteca-web`, OIDC, PKCE, configuración documentada. |
| APIs REST / Spring Boot | Servicios Angular para endpoints públicos, privados y especiales. |
| Keycloak + Spring Security | Interceptor Bearer, guards y manejo de 401/403; el backend conserva la decisión de seguridad. |
| App Web - Angular | Componentes standalone, rutas, catálogo público, dashboard, gestión de libros y recursos digitales. |
| Seguridad granular | Pantalla de recursos digitales con `libro:read` y `libro:download`, integrada con los endpoints protegidos. |
| RACI | La matriz funcional debe mantenerse en la documentación del proyecto y alinearse con los roles reales del realm. |
