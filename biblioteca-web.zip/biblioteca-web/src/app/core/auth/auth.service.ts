import { Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import Keycloak, { KeycloakInstance, KeycloakProfile } from 'keycloak-js';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly keycloak: KeycloakInstance = new Keycloak({
    url: environment.keycloak.url,
    realm: environment.keycloak.realm,
    clientId: environment.keycloak.clientId
  });

  readonly authenticated = signal(false);
  readonly username = signal('');
  readonly profile = signal<KeycloakProfile | null>(null);
  readonly roles = signal<string[]>([]);

  constructor(private readonly router: Router) {}

  async init(): Promise<boolean> {
    if (!environment.keycloak.enabled) {
      this.authenticated.set(false);
      this.username.set('');
      this.roles.set([]);
      return false;
    }

    const authenticated = await this.keycloak.init({
      onLoad: 'check-sso',
      pkceMethod: 'S256',
      checkLoginIframe: false,
      silentCheckSsoRedirectUri: `${window.location.origin}/assets/silent-check-sso.html`
    });

    this.authenticated.set(authenticated);
    if (authenticated) {
      this.username.set(this.keycloak.tokenParsed?.['preferred_username'] ?? '');
      this.roles.set(this.readRoles());
      try {
        this.profile.set(await this.keycloak.loadUserProfile());
      } catch {
        this.profile.set(null);
      }
    }
    return authenticated;
  }

  async login(): Promise<void> {
    if (!environment.keycloak.enabled) {
      this.authenticated.set(true);
      this.username.set('demo');
      this.roles.set(environment.demoRoles);
      await this.router.navigateByUrl('/libros');
      return;
    }
    await this.keycloak.login({ redirectUri: `${window.location.origin}/libros` });
  }

  async logout(): Promise<void> {
    if (environment.keycloak.enabled) {
      await this.keycloak.logout({ redirectUri: window.location.origin });
    }
    this.authenticated.set(false);
    this.profile.set(null);
    this.username.set('');
    this.roles.set([]);
    await this.router.navigateByUrl('/');
  }

  getToken(): string | undefined {
    return environment.keycloak.enabled ? this.keycloak.token : undefined;
  }

  async updateToken(): Promise<boolean> {
    return environment.keycloak.enabled ? this.keycloak.updateToken(30) : true;
  }

  hasRole(role: string): boolean {
    return this.roles().includes(role);
  }

  hasAnyRole(roles: string[]): boolean {
    return roles.some(role => this.hasRole(role));
  }

  private readRoles(): string[] {
    const realmRoles = this.keycloak.tokenParsed?.['realm_access']?.['roles'] ?? [];
    const clientRoles = this.keycloak.tokenParsed?.['resource_access']?.['biblioteca-api']?.['roles'] ?? [];
    return [...new Set([...realmRoles, ...clientRoles])];
  }
}
