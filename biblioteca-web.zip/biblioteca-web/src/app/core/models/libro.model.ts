export type EstadoLibro = 'DISPONIBLE' | 'PRESTADO';
export type TipoLibro = 'FISICO' | 'DIGITAL';

export interface Libro {
  id: number;
  codigo: string;
  titulo: string;
  autor: string;
  estado: EstadoLibro;
  tipo: TipoLibro;
}

export interface LibroRequest {
  codigo: string;
  titulo: string;
  autor: string;
  tipo: TipoLibro;
}
