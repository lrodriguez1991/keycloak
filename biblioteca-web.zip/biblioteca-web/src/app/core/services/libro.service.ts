import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { EstadoLibro, Libro, LibroRequest } from '../models/libro.model';

@Injectable({ providedIn: 'root' })
export class LibroService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiUrl;

  listarPublico(): Observable<Libro[]> {
    return this.http.get<Libro[]>(`${this.baseUrl}/public/libros`);
  }

  buscarPublico(codigo: string): Observable<Libro> {
    return this.http.get<Libro>(`${this.baseUrl}/public/libros/${encodeURIComponent(codigo)}`);
  }

  listarInterno(): Observable<Libro[]> {
    return this.http.get<Libro[]>(`${this.baseUrl}/libros`);
  }

  registrar(request: LibroRequest, archivo?: File | null): Observable<Libro> {
    const formData = new FormData();
    formData.append('codigo', request.codigo);
    formData.append('titulo', request.titulo);
    formData.append('autor', request.autor);
    formData.append('tipo', request.tipo);

    if (archivo) {
      formData.append('archivo', archivo);
    }

    return this.http.post<Libro>(`${this.baseUrl}/libros`, formData);
  }

  cambiarEstado(id: number, estado: EstadoLibro): Observable<Libro> {
    const params = new HttpParams().set('estado', estado);
    return this.http.patch<Libro>(`${this.baseUrl}/libros/${id}/estado`, null, { params });
  }

  visualizarLibroDigital(id: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/libros/${id}/leer`, {
      responseType: 'blob'
    });
  }

  descargarLibroDigital(id: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/libros/${id}/download`, {
      responseType: 'blob'
    });
  }
}
