import { Component, inject, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Libro } from '../../core/models/libro.model';
import { LibroService } from '../../core/services/libro.service';
import { AuthService } from '../../core/auth/auth.service';

@Component({
  standalone: true,
  imports: [RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  private readonly service = inject(LibroService);
  readonly authService = inject(AuthService);
  libros: Libro[] = [];
  seleccionado: Libro | null = null;
  error = '';

  ngOnInit(): void { this.cargarCatalogo(); }

  cargarCatalogo(): void {
    this.error = '';
    this.service.listarPublico().subscribe({
      next: data => this.libros = data,
      error: err => this.error = err?.message ?? 'No fue posible consultar el catálogo.'
    });
  }

  seleccionar(libro: Libro): void {
    this.error = '';
    this.service.buscarPublico(libro.codigo).subscribe({
      next: data => this.seleccionado = data,
      error: err => this.error = err?.message ?? 'No fue posible consultar el libro.'
    });
  }
}
