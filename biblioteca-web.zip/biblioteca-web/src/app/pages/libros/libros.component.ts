import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';
import { AuthService } from '../../core/auth/auth.service';
import { EstadoLibro, Libro, LibroRequest } from '../../core/models/libro.model';
import { LibroService } from '../../core/services/libro.service';

@Component({
  standalone: true,
  imports: [FormsModule],
  templateUrl: './libros.component.html',
  styleUrl: './libros.component.css'
})
export class LibrosComponent implements OnInit, OnDestroy {
  readonly auth = inject(AuthService);
  private readonly service = inject(LibroService);
  private readonly sanitizer = inject(DomSanitizer);
  libros: Libro[] = [];
  error = '';
  mensaje = '';
  mostrarNuevo = false;
  mostrarEstado = false;
  mostrarVista = false;
  libroSeleccionado: Libro | null = null;
  pdfUrl: SafeResourceUrl | null = null;
  pdfHref: string | null = null;
  private pdfObjectUrl: string | null = null;
  nuevoEstado: EstadoLibro = 'DISPONIBLE';
  form: LibroRequest = { codigo: '', titulo: '', autor: '', tipo: 'FISICO' };
  archivoSeleccionado: File | null = null;

  ngOnInit(): void { this.cargar(); }

  ngOnDestroy(): void {
    this.limpiarPdf();
  }

  cargar(): void {
    this.error = '';
    this.service.listarInterno().subscribe({
      next: data => this.libros = data,
      error: err => this.error = this.errorFrom(err)
    });
  }

  crear(): void {
    if (this.form.tipo === 'DIGITAL' && !this.archivoSeleccionado) {
      this.error = 'Debe adjuntar un PDF para registrar un libro digital.';
      return;
    }

    this.service.registrar(this.form, this.archivoSeleccionado).subscribe({
      next: () => { this.mensaje = 'Libro registrado correctamente.'; this.mostrarNuevo = false; this.form = { codigo: '', titulo: '', autor: '', tipo: 'FISICO' }; this.archivoSeleccionado = null; this.cargar(); },
      error: err => this.error = this.errorFrom(err)
    });
  }

  seleccionarArchivo(event: Event): void {
    const input = event.target as HTMLInputElement;
    const archivo = input.files?.[0] ?? null;

    if (!archivo) {
      this.archivoSeleccionado = null;
      return;
    }

    const esPdf = archivo.type === 'application/pdf' || archivo.name.toLowerCase().endsWith('.pdf');

    if (!esPdf) {
      this.archivoSeleccionado = null;
      input.value = '';
      this.error = 'El archivo seleccionado debe ser un PDF.';
      return;
    }

    this.error = '';
    this.archivoSeleccionado = archivo;
    this.form.tipo = 'DIGITAL';
  }

  cambiarTipo(): void {
    if (this.form.tipo !== 'DIGITAL') {
      this.archivoSeleccionado = null;
    }
  }

  abrirEstado(libro: Libro): void { this.libroSeleccionado = libro; this.nuevoEstado = libro.estado; this.mostrarEstado = true; }

  confirmarEstado(): void {
    if (!this.libroSeleccionado) return;
    this.service.cambiarEstado(this.libroSeleccionado.id, this.nuevoEstado).subscribe({
      next: () => { this.mensaje = 'Estado actualizado correctamente.'; this.mostrarEstado = false; this.cargar(); },
      error: err => this.error = this.errorFrom(err)
    });
  }

  visualizar(libro: Libro): void {
    this.error = '';
    this.mensaje = '';
    this.limpiarPdf();
    this.libroSeleccionado = libro;
    this.mostrarVista = true;

    if (libro.tipo !== 'DIGITAL') {
      return;
    }

    this.service.visualizarLibroDigital(libro.id).subscribe({
      next: blob => {
        const pdfBlob = new Blob([blob], { type: 'application/pdf' });
        this.pdfObjectUrl = URL.createObjectURL(pdfBlob);
        this.pdfHref = this.pdfObjectUrl;
        this.pdfUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.pdfObjectUrl);
      },
      error: err => {
        this.mostrarVista = false;
        this.libroSeleccionado = null;
        this.error = this.errorFrom(err);
      }
    });
  }

  cerrarVista(): void {
    this.mostrarVista = false;
    this.libroSeleccionado = null;
    this.limpiarPdf();
  }

  descargar(libro: Libro): void {
    this.service.descargarLibroDigital(libro.id).subscribe({
      next: blob => { const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `${libro.codigo}.pdf`; a.click(); URL.revokeObjectURL(url); },
      error: err => this.error = this.errorFrom(err)
    });
  }

  private limpiarPdf(): void {
    if (this.pdfObjectUrl) {
      URL.revokeObjectURL(this.pdfObjectUrl);
    }
    this.pdfObjectUrl = null;
    this.pdfHref = null;
    this.pdfUrl = null;
  }

  private errorFrom(err: { status?: number; error?: { message?: string } }): string {
    if (err.status === 401) return '401: sesión no autenticada o token inválido.';
    if (err.status === 403) return '403: no tienes autorización para esta operación.';
    return err.error?.message ?? 'No fue posible comunicarse con la API.';
  }
}
