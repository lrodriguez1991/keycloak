export const environment = {
  production: false,
  apiUrl: '/api',
  keycloak: {
    enabled: true,
    url: 'http://localhost:8080',
    realm: 'biblioteca-interna',
    clientId: 'biblioteca-web'
  },
  demoRoles: [
    'LIBRO_CONSULTAR',
    'LIBRO_CREAR',
    'LIBRO_CAMBIAR_ESTADO',
    'LIBRO_DIGITAL_DESCARGAR'
  ]
};
