# Biblioteca KeyCloak - API REST y Seguridad

## 1. Objetivo

Este documento describe la arquitectura funcional y de seguridad del backend `biblioteca-api`.

Complementa la implementación existente y documenta las APIs públicas, privadas y especiales, el flujo de autenticación y autorización, los recursos gestionados, la relación entre usuarios, grupos, subgrupos y roles, la matriz RACI y el uso de Keycloak Authorization Services.


## 2. Arquitectura conceptual

```text
Angular biblioteca-web (4200)
          |
          | OIDC / JWT
          v
Keycloak / biblioteca-interna (8080)
          |
          | Access Token / Roles
          v
Spring Boot / biblioteca-api (8081)
      |                 |
      |                 +--> Keycloak Authorization Services
      v
PostgreSQL
```

## 3. Clasificación de accesos

### 3.1 Acceso público

No requiere autenticación.

| Método | Endpoint | Descripción |
| --- | --- | --- |
| GET | `/api/public/libros` | Consulta del catálogo público |
| GET | `/api/public/libros/{codigo}` | Consulta de un libro por código |

### 3.2 Acceso privado

Requiere autenticación mediante Keycloak y un JWT válido.

| Método | Endpoint | Descripción |
|---|---|---|
| GET | `/api/libros` | Consulta de libros internos |
| POST | `/api/libros` | Registro de un nuevo libro |
| PATCH | `/api/libros/{id}/estado` | Cambio de estado de un libro |

Roles de cliente utilizados:

- `LIBRO_CONSULTAR`
- `LIBRO_CREAR`
- `LIBRO_CAMBIAR_ESTADO`
- `LIBRO_DIGITAL_DESCARGAR`

### 3.3 Acceso especial

Corresponde a los recursos digitales y utiliza adicionalmente Keycloak Authorization Services.

| Método | Endpoint | Descripción |
|---|---|---|
| GET | `/api/recursos-digitales` | Consulta de recursos digitales |
| GET | `/api/recursos-digitales/{id}/download` | Descarga de recurso digital |

Recurso protegido:

```text
libro-digital
```

Scopes:

```text
libro:read
libro:download
```

## 4. Proceso de negocio

El proceso principal es la gestión del catálogo de libros:

```text
Consulta catálogo
      |
      +--> Público
      |
      +--> Usuario autenticado
              |
              +--> Consultar libros
              +--> Registrar libro
              +--> Cambiar estado
              |
              +--> Recurso digital
                       |
                       +--> Consultar
                       +--> Descargar
```

## 5. Modelo de autorización

### Keycloak

Keycloak administra:

- Realm `biblioteca-interna`.
- Usuarios.
- Grupos y subgrupos.
- Roles de realm.
- Roles del cliente `biblioteca-api`.
- Scopes.
- Resources.
- Policies.
- Permissions.

### Spring Security

El backend utiliza `SecurityFilterChain` para el filtro general de seguridad.

El JWT emitido por Keycloak es validado antes de permitir el acceso a los endpoints protegidos. La autorización también puede realizarse a nivel de método mediante `@PreAuthorize`.

### Authorization Services

Para los recursos digitales se utiliza:

```text
Resource
  |
  +-- Scope: libro:read
  |
  +-- Scope: libro:download
          |
          v
        Policy
          |
          v
      Permission
```

Configuración funcional:

```text
Resource:
  libro-digital

Scopes:
  libro:read
  libro:download

Policies:
  ConsultaLibroDigitalPolicy
  DescargaLibroDigitalPolicy

Permissions:
  ConsultarLibroDigitalScopePermission
  DescargarLibroDigitalPermission
```

## 6. Roles del cliente

El cliente `biblioteca-api` utiliza:

| Rol | Responsabilidad |
|---|---|
| `LIBRO_CONSULTAR` | Consultar libros |
| `LIBRO_CREAR` | Registrar libros |
| `LIBRO_CAMBIAR_ESTADO` | Cambiar el estado de un libro |
| `LIBRO_DIGITAL_DESCARGAR` | Descargar recursos digitales |

## 7. Usuarios, grupos y subgrupos

La estructura funcional del realm `biblioteca-interna` contempla:

```text
BIBLIOTECA
|
+-- ADMINISTRACION
+-- ATENCION
+-- GESTION
```

Roles funcionales:

```text
ADMIN_BIBLIOTECA
BIBLIOTECARIO
SUPERVISOR
```

Relación:

| Perfil | Grupo/Subgrupo | Rol funcional |
|---|---|---|
| Admin | `/BIBLIOTECA/ADMINISTRACION` | `ADMIN_BIBLIOTECA` |
| Bibliotecario | `/BIBLIOTECA/ATENCION` | `BIBLIOTECARIO` |
| Supervisor | `/BIBLIOTECA/GESTION` | `SUPERVISOR` |

La asignación efectiva de permisos sobre las APIs se complementa con los roles específicos del cliente `biblioteca-api`.

## 8. Matriz funcional / RACI

### Leyenda

- **R - Responsible:** responsable de ejecutar la operación.
- **A - Accountable:** responsable final.
- **C - Consulted:** participa como consultado.
- **I - Informed:** debe ser informado.

| Operación | Supervisor | Bibliotecario | Admin | Público |
|---|---:|---:|---:|---:|
| Consultar catálogo público | R | R | R | R |
| Consultar libros internos | R | R | R | I |
| Crear libro | I | I | A/R | I |
| Cambiar estado | I | A/R | C | I |
| Consultar recurso digital | A/R | R | R | I |
| Descargar recurso digital | I | A/R* | A/R* | I |
| Administrar Keycloak | I | I | A/R | I |

> La operación marcada con `*` depende además del scope, policy y permission configurados en Keycloak Authorization Services.

### Relación RACI con autorización técnica

```text
Usuario
  |
  v
Grupo / Subgrupo
  |
  v
Rol funcional
  |
  v
Rol del cliente biblioteca-api
  |
  v
Spring Security
  |
  v
Authorization Services
  |
  +-- Resource
  +-- Scope
  +-- Policy
  +-- Permission
  |
  v
Recurso / Operación
```

## 9. Relación entre operaciones y roles técnicos

| Operación | Rol técnico principal |
|---|---|
| Consultar libros | `LIBRO_CONSULTAR` |
| Registrar libro | `LIBRO_CREAR` |
| Cambiar estado | `LIBRO_CAMBIAR_ESTADO` |
| Descargar recurso digital | `LIBRO_DIGITAL_DESCARGAR` |

En los recursos digitales, el rol participa además en la evaluación de las policies configuradas en Keycloak.

## 10. Flujo de una petición protegida

```text
Angular
   |
   | Authorization: Bearer <JWT>
   v
Spring Boot
   |
   v
SecurityFilterChain
   |
   +-- Token válido?
   |      |
   |      +-- No --> 401 Unauthorized
   |      |
   |      +-- Sí
   |
   v
Validación de roles
   |
   +-- Sin permiso --> 403 Forbidden
   |
   +-- Con permiso
          |
          v
      Controller
          |
          v
       Service
          |
          v
      PostgreSQL
```

Para recursos digitales se incorpora adicionalmente la evaluación mediante Keycloak Authorization Services.

## 11. Resumen de APIs

```text
API pública
+-- /api/public/libros
    +-- /api/public/libros/{codigo}

API privada
+-- /api/libros
    +-- GET
    +-- POST
    +-- PATCH /{id}/estado

API especial
+-- /api/recursos-digitales
    +-- GET
    +-- GET /{id}/download
```

## 12. Responsabilidad de cada componente

| Componente | Responsabilidad |
|---|---|
| Angular | Interfaz, inicio de sesión y consumo de APIs |
| Keycloak | Identidad, autenticación y emisión de tokens |
| Spring Security | Validación del JWT y autorización |
| Authorization Services | Autorización granular por recurso/scope/policy/permission |
| Spring Boot | APIs y reglas de negocio |
| PostgreSQL | Persistencia de la biblioteca |

## 13. Alcance

Este README documenta la arquitectura y el modelo funcional de seguridad del backend sin introducir cambios innecesarios en la implementación.

Sirve como evidencia documental para la descripción de APIs REST, accesos públicos/privados/especiales, matriz RACI y seguridad granular del proyecto final de Security with Keycloak.

Los valores concretos de configuración de Keycloak se mantienen en la configuración del proyecto y en el realm exportado correspondiente.
