package pe.biblioteca.config;

import org.keycloak.authorization.client.AuthzClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BibliotecaAuthorizationConfig {

    @Bean
    public AuthzClient authzClient() {
        return AuthzClient.create();
    }
}
