package pe.biblioteca.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component("bibliotecaSeguridadProperties")
@ConfigurationProperties(prefix = "biblioteca.seguridad")
public class BibliotecaSeguridadProperties {

    private String clientId;
    private Roles roles = new Roles();
    private Authorization authorization = new Authorization();

    @Data
    public static class Roles {
        private String consultar;
        private String crear;
        private String cambiarEstado;
        private String visualizarDigital;
        private String descargarDigital;
    }

    @Data
    public static class Authorization {
        private String resource;
        private Scopes scopes = new Scopes();
    }

    @Data
    public static class Scopes {
        private String read;
        private String download;
    }
}
