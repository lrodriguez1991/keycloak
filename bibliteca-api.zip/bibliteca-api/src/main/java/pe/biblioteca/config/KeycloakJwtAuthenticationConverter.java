package pe.biblioteca.config;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

public class KeycloakJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

	private final String clientId;

	public KeycloakJwtAuthenticationConverter(String clientId) {
		this.clientId = clientId;
	}

	@Override
	public AbstractAuthenticationToken convert(Jwt source) {
		List<GrantedAuthority> authorities = new ArrayList<>();

		Map<String, Object> realmAccess = source.getClaim("realm_access");

		if (realmAccess != null) {

			Object rolesObject = realmAccess.get("roles");

			if (rolesObject instanceof Collection<?> roles) {

				roles.stream().filter(String.class::isInstance).map(String.class::cast)
						.map(role -> (GrantedAuthority) new SimpleGrantedAuthority("ROLE_" + role))
						.forEach(authorities::add);
			}
		}

		Map<String, Object> resourceAccess = source.getClaim("resource_access");

		if (resourceAccess != null) {

			Object clientObject = resourceAccess.get(clientId);

			if (clientObject instanceof Map<?, ?> client) {

				Object clientRolesObject = client.get("roles");

				if (clientRolesObject instanceof Collection<?> clientRoles) {

					clientRoles.stream().filter(String.class::isInstance).map(String.class::cast)
							.map(role -> (GrantedAuthority) new SimpleGrantedAuthority("ROLE_" + role))
							.forEach(authorities::add);
				}
			}
		}

		return new JwtAuthenticationToken(source, authorities);
	}

}
