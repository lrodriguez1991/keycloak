package pe.biblioteca.controller;

import lombok.RequiredArgsConstructor;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.multipart.MultipartFile;

import pe.biblioteca.domain.EstadoLibro;
import pe.biblioteca.domain.TipoLibro;
import pe.biblioteca.dto.LibroRequest;
import pe.biblioteca.dto.LibroResponse;
import pe.biblioteca.service.KeycloakAuthorizationService;
import pe.biblioteca.service.LibroService;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class LibroController {

	private final LibroService libroService;

	private final KeycloakAuthorizationService keycloakAuthorizationService;

	@GetMapping("/public/libros")
	public List<LibroResponse> listarPublico() {
		return libroService.listar();
	}

	@GetMapping("/public/libros/{codigo}")
	public LibroResponse buscarPublico(@PathVariable String codigo) {
		return libroService.buscarPorCodigo(codigo);
	}

	@GetMapping("/libros")
	public List<LibroResponse> listarInterno() {
		return libroService.listarInterno();
	}

	@PostMapping(value = "/libros", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@ResponseStatus(HttpStatus.CREATED)
	public LibroResponse registrar(
			@RequestParam String codigo,
			@RequestParam String titulo,
			@RequestParam String autor,
			@RequestParam TipoLibro tipo,
			@RequestPart(required = false) MultipartFile archivo) {

		LibroRequest request = new LibroRequest(codigo, titulo, autor, tipo);
		return libroService.registrar(request, archivo);
	}

	@PatchMapping("/libros/{id}/estado")
	public LibroResponse cambiarEstado(@PathVariable Long id, @RequestParam EstadoLibro estado) {
		return libroService.cambiarEstado(id, estado);
	}

	@GetMapping("/libros/{id}/leer")
	public ResponseEntity<Resource> visualizarLibroDigital(@PathVariable Long id, Authentication authentication) {

		if (!keycloakAuthorizationService.tienePermisoLectura(authentication)) {
			throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permiso para visualizar libros digitales");
		}
		return libroService.visualizarLibroDigital(id);
	}

	@GetMapping("/libros/{id}/download")
	public ResponseEntity<Resource> descargarLibroDigital(@PathVariable Long id, Authentication authentication) {

		if (!keycloakAuthorizationService.tienePermisoDescarga(authentication)) {
			throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permiso para descargar libros digitales");
		}
		return libroService.descargarLibroDigital(id);
	}

}
