package pe.biblioteca.domain;

public enum EstadoLibro {
    DISPONIBLE,
    PRESTADO
}
