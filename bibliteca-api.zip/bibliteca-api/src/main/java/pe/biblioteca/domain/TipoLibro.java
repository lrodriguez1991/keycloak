package pe.biblioteca.domain;

public enum TipoLibro {
	FISICO,
	DIGITAL
}
