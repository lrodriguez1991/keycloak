package pe.biblioteca.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import pe.biblioteca.domain.TipoLibro;

public record LibroRequest(
        @NotBlank @Size(max = 20) String codigo,
        @NotBlank @Size(max = 200) String titulo,
        @NotBlank @Size(max = 150) String autor,
        @NotNull TipoLibro tipo
) {}
