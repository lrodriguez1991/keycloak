package pe.biblioteca.dto;

import pe.biblioteca.domain.EstadoLibro;
import pe.biblioteca.domain.TipoLibro;

public record LibroResponse(
        Long id,
        String codigo,
        String titulo,
        String autor,
        EstadoLibro estado,
        TipoLibro tipo
) {}
