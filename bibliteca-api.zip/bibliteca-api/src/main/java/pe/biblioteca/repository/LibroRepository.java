package pe.biblioteca.repository;

import pe.biblioteca.domain.Libro;
import pe.biblioteca.domain.TipoLibro;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LibroRepository extends JpaRepository<Libro, Long> {

    Optional<Libro> findByCodigo(String codigo);
    
    List<Libro> findByTipo(TipoLibro tipo);
}
