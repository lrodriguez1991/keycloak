package pe.biblioteca.service;

import java.util.List;

import org.keycloak.authorization.client.AuthzClient;
import org.keycloak.representations.idm.authorization.AuthorizationRequest;
import org.keycloak.representations.idm.authorization.Permission;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;

import pe.biblioteca.config.BibliotecaSeguridadProperties;

@Service
public class KeycloakAuthorizationService {

	private final AuthzClient authzClient;
	private final BibliotecaSeguridadProperties properties;

	public KeycloakAuthorizationService(AuthzClient authzClient, BibliotecaSeguridadProperties properties) {

		this.authzClient = authzClient;
		this.properties = properties;
	}

	public boolean tienePermiso(Authentication authentication, String resource, String scope) {

		if (!(authentication instanceof JwtAuthenticationToken jwtAuthentication)) {
			return false;
		}

		String accessToken = jwtAuthentication.getToken().getTokenValue();

		System.out.println("TOKEN SUBJECT: " + jwtAuthentication.getToken().getSubject());
		System.out.println("TOKEN AUD: " + jwtAuthentication.getToken().getAudience());
		System.out.println("TOKEN RESOURCE_ACCESS: " + jwtAuthentication.getToken().getClaim("resource_access"));
		System.out.println("CLIENT ID: " + properties.getClientId());
		System.out.println("RESOURCE ID: " + resource);
		System.out.println("SCOPE: " + scope);

		AuthorizationRequest request = new AuthorizationRequest();

		request.setAudience(properties.getClientId());
		request.addPermission(resource, scope);

		try {

			List<Permission> permissions = authzClient.authorization(accessToken).getPermissions(request);

			return permissions != null && !permissions.isEmpty();

		} catch (Exception e) {
			e.printStackTrace();
			throw new IllegalStateException("Error consultando autorización en Keycloak", e);
		}
	}

	public boolean tienePermisoLectura(Authentication authentication) {
		return tienePermiso(authentication, properties.getAuthorization().getResource(),
				properties.getAuthorization().getScopes().getRead());
	}

	public boolean tienePermisoDescarga(Authentication authentication) {
		return tienePermiso(authentication, properties.getAuthorization().getResource(),
				properties.getAuthorization().getScopes().getDownload());
	}
}
