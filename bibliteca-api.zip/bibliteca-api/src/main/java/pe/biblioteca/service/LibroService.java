package pe.biblioteca.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import pe.biblioteca.domain.EstadoLibro;
import pe.biblioteca.domain.Libro;
import pe.biblioteca.domain.TipoLibro;
import pe.biblioteca.dto.LibroRequest;
import pe.biblioteca.dto.LibroResponse;
import pe.biblioteca.repository.LibroRepository;

@Service
@RequiredArgsConstructor
public class LibroService {

	private final LibroRepository libroRepository;

	public List<LibroResponse> listar() {
		return libroRepository.findAll().stream().map(this::toResponse).toList();
	}

	public LibroResponse buscarPorCodigo(String codigo) {
		return libroRepository.findByCodigo(codigo).map(this::toResponse)
				.orElseThrow(() -> new IllegalArgumentException("No existe el libro con código: " + codigo));
	}

	@PreAuthorize("hasRole(@bibliotecaSeguridadProperties.roles.consultar)")
	public List<LibroResponse> listarInterno() {

		return libroRepository.findAll().stream().map(this::toResponse).toList();
	}

	@PreAuthorize("hasRole(@bibliotecaSeguridadProperties.roles.crear)")
	public LibroResponse registrar(LibroRequest request, MultipartFile archivo) {
		if (libroRepository.findByCodigo(request.codigo()).isPresent()) {
			throw new IllegalArgumentException("Ya existe un libro con código: " + request.codigo());
		}

		String archivoDigital = null;

		if (request.tipo() == TipoLibro.DIGITAL) {
			archivoDigital = guardarArchivoDigital(request.codigo(), archivo);
		}

		Libro libro = Libro.builder().codigo(request.codigo()).titulo(request.titulo()).autor(request.autor())
				.tipo(request.tipo()).estado(EstadoLibro.DISPONIBLE).archivoDigital(archivoDigital).build();

		return toResponse(libroRepository.save(libro));
	}

	@PreAuthorize("hasRole(@bibliotecaSeguridadProperties.roles.cambiarEstado)")
	public LibroResponse cambiarEstado(Long id, EstadoLibro estado) {
		Libro libro = libroRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("No existe el libro con id: " + id));

		libro.setEstado(estado);
		return toResponse(libroRepository.save(libro));
	}

	private LibroResponse toResponse(Libro libro) {
		return new LibroResponse(libro.getId(), libro.getCodigo(), libro.getTitulo(), libro.getAutor(),
				libro.getEstado(), libro.getTipo());
	}

	private String guardarArchivoDigital(String codigo, MultipartFile archivo) {
		if (archivo == null || archivo.isEmpty()) {
			throw new IllegalArgumentException("Debe adjuntar un PDF para registrar un libro digital");
		}

		String nombreOriginal = archivo.getOriginalFilename() == null ? "" : archivo.getOriginalFilename();
		String contentType = archivo.getContentType() == null ? "" : archivo.getContentType();

		if (!contentType.equalsIgnoreCase(MediaType.APPLICATION_PDF_VALUE)
				&& !nombreOriginal.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
			throw new IllegalArgumentException("El archivo digital debe ser un PDF");
		}

		try {
			Path carpeta = Paths.get("archivos-digitales").toAbsolutePath().normalize();
			Files.createDirectories(carpeta);

			String nombreArchivo = codigo.replaceAll("[^A-Za-z0-9._-]", "_") + ".pdf";
			Path destino = carpeta.resolve(nombreArchivo).normalize();

			if (!destino.startsWith(carpeta)) {
				throw new IllegalArgumentException("El nombre del archivo digital no es válido");
			}

			Files.copy(archivo.getInputStream(), destino, StandardCopyOption.REPLACE_EXISTING);
			return nombreArchivo;
		} catch (IOException e) {
			throw new IllegalArgumentException("Error al guardar el archivo digital", e);
		}
	}

	public String obtenerArchivoDigital(Long id) {

		Libro libro = libroRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("No existe el libro con id: " + id));

		if (libro.getTipo() != TipoLibro.DIGITAL) {
			throw new IllegalArgumentException("El libro no es un recurso digital");
		}

		if (libro.getArchivoDigital() == null) {
			throw new IllegalArgumentException("El libro no tiene un archivo digital asociado");
		}

		return libro.getArchivoDigital();
	}

	@PreAuthorize("hasRole(@bibliotecaSeguridadProperties.roles.visualizarDigital)")
	public ResponseEntity<Resource> visualizarLibroDigital(Long id) {
		return responderLibroDigital(id, "inline");
	}

	@PreAuthorize("hasRole(@bibliotecaSeguridadProperties.roles.descargarDigital)")
	public ResponseEntity<Resource> descargarLibroDigital(Long id) {
		return responderLibroDigital(id, "attachment");
	}

	private ResponseEntity<Resource> responderLibroDigital(Long id, String disposition) {
		Libro libro = libroRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("No existe el libro con id: " + id));

		if (libro.getTipo() != TipoLibro.DIGITAL) {
			throw new IllegalArgumentException("El libro no es un recurso digital");
		}

		if (libro.getArchivoDigital() == null || libro.getArchivoDigital().isBlank()) {
			throw new IllegalArgumentException("El libro no tiene un archivo digital asociado");
		}

		try {
			Path carpeta = Paths.get("archivos-digitales").toAbsolutePath().normalize();
			Path archivo = carpeta.resolve(libro.getArchivoDigital()).normalize();

			if (!archivo.startsWith(carpeta)) {
				throw new IllegalArgumentException("El archivo digital no es válido: " + libro.getArchivoDigital());
			}

			Resource resource = new UrlResource(archivo.toUri());

			if (!resource.exists() || !resource.isReadable()) {
				throw new IllegalArgumentException("No se encontró el archivo digital: " + libro.getArchivoDigital());
			}

			return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
					.header("Content-Disposition", disposition + "; filename=\"" + archivo.getFileName() + "\"")
					.body(resource);

		} catch (IOException e) {
			throw new IllegalArgumentException("Error al acceder al archivo digital", e);
		}
	}
}
